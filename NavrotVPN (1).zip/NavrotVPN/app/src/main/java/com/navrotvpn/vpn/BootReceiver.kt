package com.navrotvpn.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Заготовка под "подключаться автоматически после перезагрузки устройства".
 * Сейчас ничего не делает без явного пользовательского согласия —
 * это осознанное решение: автозапуск VPN без ведома пользователя
 * плохая практика. Включи логику здесь, если хочешь такое поведение,
 * и не забудь заранее спросить разрешение у пользователя в UI.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        // TODO: проверить сохранённую настройку "автоподключение при загрузке"
        // и, если включена, аккуратно поднять VpnService.prepare() flow.
    }
}
