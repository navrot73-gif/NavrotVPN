package com.navrotvpn.vpn

import org.amnezia.awg.backend.GoBackend

/**
 * Аналог VpnServiceImpl, но для AmneziaWG-бэкенда. Нужен отдельный сервис,
 * потому что AwgGoBackend и обычный GoBackend — разные Go-рантаймы под
 * разными пакетами, каждый регистрирует свой android.net.VpnService.
 */
class AmneziaVpnServiceImpl : GoBackend.VpnService() {
    override fun onCreate() {
        super.onCreate()
    }
}
