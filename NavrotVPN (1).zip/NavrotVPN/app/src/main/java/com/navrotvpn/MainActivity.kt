package com.navrotvpn

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.navrotvpn.core.ConfigManager
import com.navrotvpn.core.ConnectionState
import com.navrotvpn.core.KeyManager
import com.navrotvpn.databinding.ActivityMainBinding
import com.navrotvpn.network.ApiClient
import com.navrotvpn.network.ServerModel
import com.navrotvpn.network.VpnProtocol
import com.navrotvpn.vpn.AmneziaWgManager
import com.navrotvpn.vpn.NetworkMonitor
import com.navrotvpn.vpn.WireGuardManager
import com.navrotvpn.vpn.protocol.ProtocolRouter
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var servers: List<ServerModel> = emptyList()
    private var selectedServer: ServerModel? = null
    private var stateCollectJob: Job? = null
    private lateinit var networkMonitor: NetworkMonitor

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) doConnect() else updateStatus(ConnectionState.DISCONNECTED)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        WireGuardManager.init(applicationContext)
        AmneziaWgManager.init(applicationContext)
        networkMonitor = NetworkMonitor(applicationContext, lifecycleScope)

        showPublicKey()
        loadServers()

        binding.btnConnect.setOnClickListener {
            if (ProtocolRouter.isConnected()) doDisconnect() else requestPermissionAndConnect()
        }
        binding.btnCopyPublicKey.setOnClickListener { copyPublicKeyToClipboard() }
        binding.btnRegenerateKeys.setOnClickListener {
            KeyManager.regenerateKeyPair(applicationContext)
            showPublicKey()
            Toast.makeText(this, R.string.keys_regenerated, Toast.LENGTH_LONG).show()
        }
        binding.btnOpenVpnSettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
        }
    }

    override fun onStart() {
        super.onStart()
        networkMonitor.start()
    }

    override fun onStop() {
        networkMonitor.stop()
        super.onStop()
    }

    private fun showPublicKey() {
        binding.tvPublicKey.text = KeyManager.publicKeyBase64(applicationContext)
    }

    private fun copyPublicKeyToClipboard() {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("WireGuard public key", binding.tvPublicKey.text))
        Toast.makeText(this, R.string.public_key_copied, Toast.LENGTH_SHORT).show()
    }

    private fun loadServers() {
        lifecycleScope.launch {
            var list = ApiClient.fetchServerList()
            if (list.isEmpty()) {
                list = ConfigManager.loadBundledServers(applicationContext)
            }
            servers = list
            selectedServer = list.firstOrNull()
            onServerSelectionChanged()

            val names = list.map { "${it.name} (${it.countryCode}) — ${protocolLabel(it.protocol)}" }
            binding.spinnerServer.adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names
            )
            binding.spinnerServer.setSelection(0)
            binding.spinnerServer.onItemSelectedListener =
                object : android.widget.AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: android.widget.AdapterView<*>?, view: android.view.View?,
                        position: Int, id: Long
                    ) {
                        selectedServer = servers.getOrNull(position)
                        onServerSelectionChanged()
                    }
                    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                }
        }
    }

    private fun protocolLabel(protocol: VpnProtocol): String =
        if (ProtocolRouter.isImplemented(protocol)) protocol.name else "${protocol.name} ⚠"

    private fun onServerSelectionChanged() {
        val server = selectedServer ?: return
        observeSelectedServerState(server.protocol)
        updateProtocolNote(server)
        updateObfuscationCard(server)
    }

    private fun updateProtocolNote(server: ServerModel) {
        if (ProtocolRouter.isImplemented(server.protocol)) {
            binding.tvProtocolNote.visibility = android.view.View.GONE
        } else {
            binding.tvProtocolNote.visibility = android.view.View.VISIBLE
            binding.tvProtocolNote.text = getString(R.string.protocol_not_implemented, server.protocol.name)
        }
    }

    private fun updateObfuscationCard(server: ServerModel) {
        if (server.protocol != VpnProtocol.AMNEZIAWG) {
            binding.cardObfuscation.visibility = android.view.View.GONE
            return
        }
        binding.cardObfuscation.visibility = android.view.View.VISIBLE
        binding.tvObfuscationStatus.text = if (server.jc != null) {
            getString(R.string.obfuscation_on, server.jc, server.jMin ?: 0, server.jMax ?: 0)
        } else {
            getString(R.string.obfuscation_off)
        }
    }

    /** Переподписывается на StateFlow того обработчика, что отвечает за протокол сервера. */
    private fun observeSelectedServerState(protocol: VpnProtocol) {
        stateCollectJob?.cancel()
        stateCollectJob = lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                ProtocolRouter.stateFor(protocol).collect { state -> updateStatus(state) }
            }
        }
    }

    private fun requestPermissionAndConnect() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermissionLauncher.launch(intent) else doConnect()
    }

    private fun doConnect() {
        val server = selectedServer ?: return
        lifecycleScope.launch {
            try {
                ProtocolRouter.connect(applicationContext, server)
            } catch (e: Exception) {
                updateStatus(ConnectionState.ERROR)
                Toast.makeText(this@MainActivity, e.message ?: getString(R.string.status_error), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun doDisconnect() {
        lifecycleScope.launch { ProtocolRouter.disconnect() }
    }

    private fun updateStatus(state: ConnectionState) {
        binding.progressBar.visibility =
            if (state == ConnectionState.CONNECTING) android.view.View.VISIBLE else android.view.View.GONE
        when (state) {
            ConnectionState.DISCONNECTED -> {
                binding.tvStatus.text = getString(R.string.status_disconnected)
                binding.btnConnect.text = getString(R.string.action_connect)
            }
            ConnectionState.CONNECTING -> binding.tvStatus.text = getString(R.string.status_connecting)
            ConnectionState.CONNECTED -> {
                binding.tvStatus.text = getString(R.string.status_connected)
                binding.btnConnect.text = getString(R.string.action_disconnect)
            }
            ConnectionState.ERROR -> {
                binding.tvStatus.text = getString(R.string.status_error)
                binding.btnConnect.text = getString(R.string.action_connect)
            }
        }
    }
}
