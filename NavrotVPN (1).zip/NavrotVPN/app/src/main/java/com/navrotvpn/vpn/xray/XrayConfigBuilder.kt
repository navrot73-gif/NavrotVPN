package com.navrotvpn.vpn.xray

import com.navrotvpn.network.ServerModel
import com.navrotvpn.network.VpnProtocol
import org.json.JSONArray
import org.json.JSONObject

/**
 * Собирает полный JSON-конфиг xray-core для CoreController.startLoop().
 *
 * Поддерживает два протокола на одном и том же движке:
 *  - V2RAY   — если server.v2rayConfigJson задан, ожидается готовый объект
 *              outbound (protocol: vmess/vless + settings/streamSettings),
 *              который просто оборачивается в полный конфиг.
 *  - TROJAN  — собирается из trojanPassword/trojanSni/endpoint напрямую.
 *
 * DNS-протекция: 1.1.1.1/1.0.0.1 через сам туннель, чтобы DNS-запросы не
 * утекали мимо VPN — частая дыра в самодельных клиентах.
 */
object XrayConfigBuilder {

    fun build(server: ServerModel): String {
        val outbound = when (server.protocol) {
            VpnProtocol.V2RAY -> buildV2rayOutbound(server)
            VpnProtocol.TROJAN -> buildTrojanOutbound(server)
            else -> throw IllegalArgumentException("XrayConfigBuilder не поддерживает ${server.protocol}")
        }

        val root = JSONObject()
        root.put("log", JSONObject().put("loglevel", "warning"))

        root.put(
            "dns",
            JSONObject().put("servers", JSONArray().put("1.1.1.1").put("1.0.0.1"))
        )

        // Локальные inbound не нужны: CoreController.startLoop() принимает
        // файловый дескриптор TUN-интерфейса напрямую (см. tunFdKey в
        // libv2ray_main.go) — ядро само разбирает IP-пакеты с этого fd.
        root.put("inbounds", JSONArray())

        val outbounds = JSONArray()
        outbound.put("tag", "proxy")
        outbounds.put(outbound)
        outbounds.put(JSONObject().put("protocol", "freedom").put("tag", "direct"))
        outbounds.put(JSONObject().put("protocol", "blackhole").put("tag", "block"))
        root.put("outbounds", outbounds)

        root.put("routing", JSONObject().put("domainStrategy", "AsIs").put("rules", JSONArray()))

        return root.toString()
    }

    private fun buildV2rayOutbound(server: ServerModel): JSONObject {
        val raw = server.v2rayConfigJson
            ?: throw IllegalArgumentException("У сервера не задан v2rayConfigJson")
        // Ожидаем уже готовый объект outbound (protocol+settings+
        // streamSettings), например экспортированный из панели 3x-ui/x-ui
        // или распарсенный из ссылки vmess://... / vless://...
        return JSONObject(raw)
    }

    private fun buildTrojanOutbound(server: ServerModel): JSONObject {
        val password = server.trojanPassword
            ?: throw IllegalArgumentException("У сервера не задан trojanPassword")
        val parts = server.endpoint.split(":")
        if (parts.size != 2) throw IllegalArgumentException("endpoint должен быть host:port")
        val host = parts[0]
        val port = parts[1].toInt()

        val serverEntry = JSONObject()
            .put("address", host)
            .put("port", port)
            .put("password", password)

        val settings = JSONObject().put("servers", JSONArray().put(serverEntry))

        val streamSettings = JSONObject()
            .put("network", "tcp")
            .put("security", "tls")
            .put("tlsSettings", JSONObject().put("serverName", server.trojanSni ?: host))

        return JSONObject()
            .put("protocol", "trojan")
            .put("settings", settings)
            .put("streamSettings", streamSettings)
    }
}
