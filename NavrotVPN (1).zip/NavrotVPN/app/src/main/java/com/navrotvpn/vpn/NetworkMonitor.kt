package com.navrotvpn.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.navrotvpn.vpn.protocol.ProtocolRouter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Следит за сменой сети (Wi-Fi <-> мобильная, обрыв и восстановление
 * интернета) и просит ProtocolRouter переподключить активный туннель —
 * какой бы протокол ни был выбран (WireGuard, AmneziaWG и т.д.).
 *
 * Регистрировать в MainActivity.onStart()/остановить в onStop().
 */
class NetworkMonitor(
    private val context: Context,
    private val scope: CoroutineScope
) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private var wasConnectedBeforeLoss = false
    private var registered = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {

        override fun onLost(network: Network) {
            wasConnectedBeforeLoss = ProtocolRouter.isConnected()
        }

        override fun onAvailable(network: Network) {
            if (!wasConnectedBeforeLoss) return
            wasConnectedBeforeLoss = false
            scope.launch { ProtocolRouter.reconnectActiveIfNeeded(context) }
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            if (ProtocolRouter.isConnected()) return
            if (!wasConnectedBeforeLoss) return
            wasConnectedBeforeLoss = false
            scope.launch { ProtocolRouter.reconnectActiveIfNeeded(context) }
        }
    }

    fun start() {
        if (registered) return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        connectivityManager.registerNetworkCallback(request, networkCallback)
        registered = true
    }

    fun stop() {
        if (!registered) return
        connectivityManager.unregisterNetworkCallback(networkCallback)
        registered = false
    }
}
