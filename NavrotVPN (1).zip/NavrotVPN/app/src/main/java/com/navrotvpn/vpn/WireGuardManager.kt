package com.navrotvpn.vpn

import android.content.Context
import com.navrotvpn.core.ConfigManager
import com.navrotvpn.core.ConnectionState
import com.navrotvpn.network.ServerModel
import com.navrotvpn.vpn.protocol.TunnelProtocolHandler
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Синглтон, оборачивающий GoBackend (нативная реализация WireGuard от Google/WireGuard.com).
 * MainActivity вызывает connect()/disconnect(), а UI подписывается на state.
 */
object WireGuardManager : TunnelProtocolHandler {

    private const val TUNNEL_NAME = "navrotvpn"

    private lateinit var backend: Backend
    private var tunnel: WgTunnel? = null
    private var currentServer: ServerModel? = null

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    override val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        backend = GoBackend(context.applicationContext)
        initialized = true
    }

    override suspend fun connect(context: Context, server: ServerModel) = withContext(Dispatchers.IO) {
        init(context)
        _state.value = ConnectionState.CONNECTING
        try {
            val config = ConfigManager.buildConfig(context, server)
            val t = tunnel ?: WgTunnel(TUNNEL_NAME) { wgState ->
                _state.value = when (wgState) {
                    Tunnel.State.UP -> ConnectionState.CONNECTED
                    Tunnel.State.DOWN -> ConnectionState.DISCONNECTED
                    else -> ConnectionState.CONNECTING
                }
            }.also { tunnel = it }

            backend.setState(t, Tunnel.State.UP, config)
            currentServer = server
            _state.value = ConnectionState.CONNECTED
        } catch (e: Exception) {
            _state.value = ConnectionState.ERROR
            throw e
        }
    }

    override suspend fun disconnect() = withContext(Dispatchers.IO) {
        val t = tunnel ?: return@withContext
        try {
            backend.setState(t, Tunnel.State.DOWN, null)
        } finally {
            _state.value = ConnectionState.DISCONNECTED
        }
    }

    override suspend fun reconnectIfNeeded(context: Context) {
        val server = currentServer ?: return
        if (_state.value == ConnectionState.CONNECTED || _state.value == ConnectionState.ERROR) {
            connect(context, server)
        }
    }

    override fun isConnected(): Boolean = _state.value == ConnectionState.CONNECTED
}
