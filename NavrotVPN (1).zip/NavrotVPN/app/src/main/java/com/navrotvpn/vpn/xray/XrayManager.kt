package com.navrotvpn.vpn.xray

import android.content.Context
import android.content.Intent
import com.navrotvpn.core.ConnectionState
import com.navrotvpn.network.ServerModel
import com.navrotvpn.vpn.protocol.TunnelProtocolHandler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Обёртка над V2RayVpnService — общий менеджер для V2Ray и Trojan
 * (оба гоняются на одном и том же xray-core, отличается только outbound
 * в JSON-конфиге, который собирает XrayConfigBuilder).
 */
object XrayManager : TunnelProtocolHandler {

    private val _state = MutableStateFlow(ConnectionState.DISCONNECTED)
    override val state: StateFlow<ConnectionState> = _state.asStateFlow()

    private var currentServer: ServerModel? = null
    private var appContext: Context? = null

    init {
        V2RayVpnService.onStatusChanged = { running ->
            _state.value = if (running) ConnectionState.CONNECTED else ConnectionState.DISCONNECTED
        }
    }

    override suspend fun connect(context: Context, server: ServerModel) {
        _state.value = ConnectionState.CONNECTING
        currentServer = server
        appContext = context.applicationContext
        try {
            val configJson = XrayConfigBuilder.build(server)
            val intent = Intent(context, V2RayVpnService::class.java)
                .putExtra(V2RayVpnService.EXTRA_CONFIG_JSON, configJson)
            context.startService(intent)
        } catch (e: Exception) {
            _state.value = ConnectionState.ERROR
            throw e
        }
    }

    override suspend fun disconnect() {
        currentServer = null
        appContext?.let { ctx ->
            ctx.stopService(Intent(ctx, V2RayVpnService::class.java))
        }
        // onDestroy() сервиса дополнительно переведёт state в DISCONNECTED через колбэк
    }

    override suspend fun reconnectIfNeeded(context: Context) {
        val server = currentServer ?: return
        if (_state.value == ConnectionState.CONNECTED || _state.value == ConnectionState.ERROR) {
            connect(context, server)
        }
    }

    override fun isConnected(): Boolean = _state.value == ConnectionState.CONNECTED
}
