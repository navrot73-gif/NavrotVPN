package com.navrotvpn.vpn.protocol

import android.content.Context
import com.navrotvpn.core.ConnectionState
import com.navrotvpn.network.ServerModel
import com.navrotvpn.network.VpnProtocol
import com.navrotvpn.vpn.AmneziaWgManager
import com.navrotvpn.vpn.WireGuardManager
import com.navrotvpn.vpn.xray.XrayManager
import kotlinx.coroutines.flow.StateFlow

/**
 * Единая точка входа для UI: выбирает нужный TunnelProtocolHandler по
 * ServerModel.protocol и делегирует ему connect/disconnect.
 *
 * Полностью рабочие: WIREGUARD, AMNEZIAWG, V2RAY, TROJAN (последние два —
 * через общий XrayManager/xray-core, см. vpn/xray/).
 * Остальные (Shadowsocks, Hysteria2, OpenVPN, IKEv2) — заглушки с честным
 * NotImplementedError и инструкцией внутри своих файлов.
 */
object ProtocolRouter {

    private val wireGuard: TunnelProtocolHandler = WireGuardManager
    private val amneziaWg: TunnelProtocolHandler = AmneziaWgManager
    private val xray: TunnelProtocolHandler = XrayManager
    private val shadowsocks: TunnelProtocolHandler = ShadowsocksProtocolHandler()
    private val hysteria2: TunnelProtocolHandler = Hysteria2ProtocolHandler()
    private val openVpn: TunnelProtocolHandler = OpenVpnProtocolHandler()
    private val ikev2: TunnelProtocolHandler = Ikev2ProtocolHandler()

    private var active: TunnelProtocolHandler = wireGuard

    private fun handlerFor(protocol: VpnProtocol): TunnelProtocolHandler = when (protocol) {
        VpnProtocol.WIREGUARD -> wireGuard
        VpnProtocol.AMNEZIAWG -> amneziaWg
        VpnProtocol.V2RAY -> xray
        VpnProtocol.TROJAN -> xray
        VpnProtocol.SHADOWSOCKS -> shadowsocks
        VpnProtocol.HYSTERIA2 -> hysteria2
        VpnProtocol.OPENVPN -> openVpn
        VpnProtocol.IKEV2 -> ikev2
    }

    /** true, если протокол реально работает (не заглушка). */
    fun isImplemented(protocol: VpnProtocol): Boolean = when (protocol) {
        VpnProtocol.WIREGUARD, VpnProtocol.AMNEZIAWG, VpnProtocol.V2RAY, VpnProtocol.TROJAN -> true
        else -> false
    }

    fun stateFor(protocol: VpnProtocol): StateFlow<ConnectionState> = handlerFor(protocol).state

    suspend fun connect(context: Context, server: ServerModel) {
        val next = handlerFor(server.protocol)
        if (next !== active && active.isConnected()) {
            active.disconnect()
        }
        active = next
        active.connect(context, server)
    }

    suspend fun disconnect() {
        active.disconnect()
    }

    suspend fun reconnectActiveIfNeeded(context: Context) {
        active.reconnectIfNeeded(context)
    }

    fun isConnected(): Boolean = active.isConnected()
}
