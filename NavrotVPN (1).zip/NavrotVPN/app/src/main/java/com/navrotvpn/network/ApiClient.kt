package com.navrotvpn.network

import com.navrotvpn.core.ConfigManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/**
 * Загружает список доступных серверов.
 * Сейчас смотрит на удалённый JSON, при ошибке — откатывается
 * на локальный assets/servers.json (см. ConfigManager.loadBundledServers).
 */
object ApiClient {

    private const val SERVERS_URL = "https://example.com/servers.json"

    private val client = OkHttpClient.Builder().build()

    suspend fun fetchServerList(): List<ServerModel> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(SERVERS_URL).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
                val body = response.body?.string() ?: throw IOException("Empty body")
                ConfigManager.parseServersJson(body)
            }
        } catch (e: Exception) {
            // Сеть недоступна / сервер не отвечает — вызывающий код должен
            // подставить локальный список из assets в качестве резерва.
            emptyList()
        }
    }
}
