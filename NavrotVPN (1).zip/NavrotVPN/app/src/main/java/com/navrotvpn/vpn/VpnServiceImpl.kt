package com.navrotvpn.vpn

import com.wireguard.android.backend.GoBackend

/**
 * GoBackend.VpnService уже реализует всё необходимое взаимодействие
 * с android.net.VpnService (создание tun-интерфейса, привязку сети и т.д.).
 * Наследуемся от него только для того, чтобы иметь собственное имя класса
 * в манифесте и при необходимости расширять поведение (уведомления,
 * автопереподключение и т.п.).
 */
class VpnServiceImpl : GoBackend.VpnService() {

    override fun onCreate() {
        super.onCreate()
        // Место для инициализации foreground-уведомления, если потребуется
        // постоянно висящий значок VPN с собственным текстом.
    }
}
