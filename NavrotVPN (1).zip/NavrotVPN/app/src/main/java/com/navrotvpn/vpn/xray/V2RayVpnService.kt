package com.navrotvpn.vpn.xray

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray

/**
 * VpnService для xray-core (V2Ray/VLESS/VMess/Trojan — общий движок).
 * Создаёт TUN-интерфейс средствами Android VpnService, а дальнейшую
 * обработку IP-пакетов делает сам xray-core через переданный fd
 * (CoreController.startLoop(config, tunFd)).
 *
 * ВАЖНО: имя пакета сгенерированных gomobile-классов (libv2ray.CoreController
 * и т.д.) соответствует `package libv2ray` в libv2ray_main.go на момент
 * подготовки этого файла. Если версия AndroidLibXrayLite в будущем
 * переименует пакет — поправить импорты здесь.
 */
class V2RayVpnService : VpnService(), CoreCallbackHandler {

    private var tunFd: ParcelFileDescriptor? = null
    private var controller: CoreController? = null

    companion object {
        const val EXTRA_CONFIG_JSON = "config_json"
        var onStatusChanged: ((running: Boolean) -> Unit)? = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val config = intent?.getStringExtra(EXTRA_CONFIG_JSON)
        if (config == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startXray(config)
        return START_STICKY
    }

    private fun startXray(configJson: String) {
        Libv2ray.initCoreEnv(filesDir.absolutePath, "")

        val builder = Builder()
            .setSession("NavrotVPN-Xray")
            .addAddress("10.88.88.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setMtu(1400)

        val pfd = builder.establish() ?: run {
            stopSelf()
            return
        }
        tunFd = pfd

        val c = Libv2ray.newCoreController(this)
        controller = c

        // detachFd() отдаёт файловый дескриптор нативному коду; после этого
        // Android-стороне сам ParcelFileDescriptor больше не принадлежит —
        // закрывать его будет xray-core при остановке.
        val fd = pfd.detachFd()
        Thread {
            try {
                c.startLoop(configJson, fd)
            } catch (e: Exception) {
                onStatusChanged?.invoke(false)
                stopSelf()
            }
        }.start()
    }

    override fun onDestroy() {
        controller?.stopLoop()
        controller = null
        tunFd = null
        onStatusChanged?.invoke(false)
        super.onDestroy()
    }

    // ---- CoreCallbackHandler (колбэки из Go-ядра) ----

    override fun startup(): Long {
        onStatusChanged?.invoke(true)
        return 0
    }

    override fun shutdown(): Long {
        onStatusChanged?.invoke(false)
        return 0
    }

    override fun onEmitStatus(code: Long, message: String?): Long {
        // Сюда прилетают строковые статусы ядра (полезно для логов/отладки)
        return 0
    }
}
