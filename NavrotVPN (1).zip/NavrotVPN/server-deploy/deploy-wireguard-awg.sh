#!/usr/bin/env bash
#
# deploy-wireguard-awg.sh
# Разворачивает на чистом Ubuntu 22.04/24.04 сервере ОБА варианта:
#   1) обычный WireGuard (wg0)      — быстро, из стандартных репозиториев
#   2) AmneziaWG (awg0)             — с обфускацией против DPI, из
#                                      официального PPA ppa:amnezia/ppa
# и печатает всё, что нужно вставить в assets/servers.json приложения
# NavrotVPN (серверный публичный ключ, endpoint, обфускацию).
#
# Запуск (на сервере, от root):
#   curl -O <путь_к_файлу>/deploy-wireguard-awg.sh
#   chmod +x deploy-wireguard-awg.sh
#   sudo ./deploy-wireguard-awg.sh wg      # только WireGuard
#   sudo ./deploy-wireguard-awg.sh awg     # только AmneziaWG
#   sudo ./deploy-wireguard-awg.sh both    # оба сразу, на разных портах
#
set -euo pipefail

MODE="${1:-both}"
WG_PORT="${WG_PORT:-51820}"
AWG_PORT="${AWG_PORT:-51821}"
SUBNET_WG="10.66.66.1/24"
SUBNET_AWG="10.77.77.1/24"
SERVER_IP="$(curl -s -4 ifconfig.me || curl -s -4 icanhazip.com)"
IFACE="$(ip -o -4 route show to default | awk '{print $5}' | head -n1)"

echo "==> Внешний IP сервера: ${SERVER_IP}"
echo "==> Сетевой интерфейс: ${IFACE}"

apt update -y
apt install -y curl gnupg2 iptables

enable_forwarding() {
  sysctl -w net.ipv4.ip_forward=1
  grep -q '^net.ipv4.ip_forward' /etc/sysctl.conf || echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf
}

setup_wireguard() {
  echo "==> Устанавливаю обычный WireGuard"
  apt install -y wireguard wireguard-tools

  umask 077
  mkdir -p /etc/wireguard
  wg genkey | tee /etc/wireguard/server_private.key | wg pubkey > /etc/wireguard/server_public.key
  PRIV=$(cat /etc/wireguard/server_private.key)
  PUB=$(cat /etc/wireguard/server_public.key)

  cat > /etc/wireguard/wg0.conf <<EOF
[Interface]
Address = ${SUBNET_WG}
ListenPort = ${WG_PORT}
PrivateKey = ${PRIV}
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o ${IFACE} -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o ${IFACE} -j MASQUERADE

# Клиентов (Peer) добавляй сюда, либо командой:
#   wg set wg0 peer <ПУБЛИЧНЫЙ_КЛЮЧ_УСТРОЙСТВА> allowed-ips 10.66.66.2/32
EOF

  systemctl enable --now wg-quick@wg0

  echo ""
  echo "===== WireGuard готов ====="
  echo "protocol:        WIREGUARD"
  echo "endpoint:        ${SERVER_IP}:${WG_PORT}"
  echo "serverPublicKey: ${PUB}"
  echo "clientAddress:   10.66.66.2/32   (для каждого нового устройства увеличивай последний октет)"
  echo "============================"
}

setup_amneziawg() {
  echo "==> Подключаю официальный PPA Amnezia и ставлю AmneziaWG"
  apt install -y software-properties-common
  add-apt-repository -y ppa:amnezia/ppa
  apt update -y
  apt install -y amneziawg

  umask 077
  mkdir -p /etc/amnezia/amneziawg
  awg genkey | tee /etc/amnezia/amneziawg/server_private.key | awg pubkey > /etc/amnezia/amneziawg/server_public.key
  PRIV=$(cat /etc/amnezia/amneziawg/server_private.key)
  PUB=$(cat /etc/amnezia/amneziawg/server_public.key)

  # Рекомендованные диапазоны параметров обфускации (см. README AmneziaWG):
  # Jc 4-12, Jmin/Jmax задают размер мусорных пакетов, H1-H4 — уникальные
  # "магические" заголовки (должны быть разными и не совпадать между собой).
  JC=$(( (RANDOM % 9) + 4 ))
  JMIN=40
  JMAX=70
  H1=$(( RANDOM * RANDOM ))
  H2=$(( RANDOM * RANDOM ))
  H3=$(( RANDOM * RANDOM ))
  H4=$(( RANDOM * RANDOM ))

  cat > /etc/amnezia/amneziawg/awg0.conf <<EOF
[Interface]
Address = ${SUBNET_AWG}
ListenPort = ${AWG_PORT}
PrivateKey = ${PRIV}
Jc = ${JC}
Jmin = ${JMIN}
Jmax = ${JMAX}
S1 = 0
S2 = 0
H1 = ${H1}
H2 = ${H2}
H3 = ${H3}
H4 = ${H4}
PostUp = iptables -A FORWARD -i awg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o ${IFACE} -j MASQUERADE
PostDown = iptables -D FORWARD -i awg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o ${IFACE} -j MASQUERADE

# Клиентов (Peer) добавляй сюда, либо командой:
#   awg set awg0 peer <ПУБЛИЧНЫЙ_КЛЮЧ_УСТРОЙСТВА> allowed-ips 10.77.77.2/32
EOF

  systemctl enable --now awg-quick@awg0

  echo ""
  echo "===== AmneziaWG готов ====="
  echo "protocol:        AMNEZIAWG"
  echo "endpoint:        ${SERVER_IP}:${AWG_PORT}"
  echo "serverPublicKey: ${PUB}"
  echo "clientAddress:   10.77.77.2/32"
  echo "jc: ${JC}, jMin: ${JMIN}, jMax: ${JMAX}, s1: 0, s2: 0"
  echo "h1: ${H1}, h2: ${H2}, h3: ${H3}, h4: ${H4}"
  echo "============================"
}

add_wg_client() {
  local pubkey="$1" address="$2"
  wg set wg0 peer "$pubkey" allowed-ips "$address"
  wg-quick save wg0 2>/dev/null || true
  echo "Добавлен клиент WireGuard: ${pubkey} -> ${address}"
}

add_awg_client() {
  local pubkey="$1" address="$2"
  awg set awg0 peer "$pubkey" allowed-ips "$address"
  awg-quick save awg0 2>/dev/null || true
  echo "Добавлен клиент AmneziaWG: ${pubkey} -> ${address}"
}

enable_forwarding

case "$MODE" in
  wg) setup_wireguard ;;
  awg) setup_amneziawg ;;
  both) setup_wireguard; setup_amneziawg ;;
  *) echo "Использование: $0 [wg|awg|both]"; exit 1 ;;
esac

echo ""
echo "Готово. Открой порт(ы) ${WG_PORT}/udp и/или ${AWG_PORT}/udp в firewall"
echo "облачного провайдера (Security Group / Firewall Rules), если он есть отдельно от ufw."
echo ""
echo "Чтобы добавить клиента (публичный ключ смотри в NavrotVPN -> 'Публичный ключ устройства'):"
echo "  sudo bash $0 add-wg  <PUBLIC_KEY> 10.66.66.2/32"
echo "  sudo bash $0 add-awg <PUBLIC_KEY> 10.77.77.2/32"

if [ "${MODE}" = "add-wg" ]; then add_wg_client "${2:?}" "${3:?}"; fi
if [ "${MODE}" = "add-awg" ]; then add_awg_client "${2:?}" "${3:?}"; fi
