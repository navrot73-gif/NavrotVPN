# NavrotVPN

Android-клиент VPN на Kotlin с рабочими протоколами WireGuard и
AmneziaWG (обфускация против DPI), заготовками под ещё 6 протоколов,
kill-switch через системный Always-on VPN, авто-переподключением при
смене сети, генерацией ключей на устройстве и скриптом развёртывания
собственного бесплатного сервера.

## Протоколы

| Протокол | Статус | Детали |
|---|---|---|
| **WireGuard** | ✅ Работает | `com.wireguard.android:tunnel` — официальная библиотека |
| **AmneziaWG** | ✅ Работает | `com.zaneschepke:amneziawg-android` — форк WireGuard с обфускацией трафика против DPI (мусорные пакеты + случайные заголовки). Реальная антиблокировка |
| **V2Ray / VMess / VLESS** | ✅ Работает* | xray-core через `libv2ray.aar` (см. `xray-build/`). Ты собираешь `.aar` сам — в репозитории бинарник не хранится |
| **Trojan** | ✅ Работает* | тот же xray-core/`libv2ray.aar`, просто другой outbound в конфиге |
| Shadowsocks | ⚠ Заглушка | нужен AIDL-мост к shadowsocks-android либо форк его core |
| Hysteria2 | ⚠ Заглушка | нужна сборка hysteria-core под Android через gomobile |
| OpenVPN | ⚠ Заглушка | нужен NDK-модуль из ics-openvpn |
| IKEv2/IPsec | ⚠ Заглушка | strongSwan-модуль (NDK) либо системный `Ikev2VpnProfile` на Android 11+ |

\* V2Ray и Trojan помечены рабочими в коде (реальная интеграция с
`CoreController.startLoop()`, TUN отдаётся напрямую в xray-core), но
физически заработают только после того, как ты соберёшь `libv2ray.aar` —
см. раздел "V2Ray/Trojan: сборка .aar" ниже. Без него сборка `app` упадёт
на этапе `implementation files('libs/libv2ray.aar')`.

Выбор протокола — часть модели сервера (`ServerModel.protocol`), UI сам
подписывается на состояние нужного обработчика через `ProtocolRouter`.
У каждой заглушки в комментариях — точный путь к реальной интеграции.

## Антиблокировка

- **AmneziaWG** — основной реальный механизм. Параметры Jc/Jmin/Jmax/
  S1/S2/H1-H4 задаются на сервер и клиент и превращают WireGuard-трафик
  в трафик без узнаваемой DPI-сигнатуры. UI показывает включена ли
  обфускация для выбранного сервера (карточка "Обфускация" на главном
  экране).
- **Kill switch** — `VpnServiceImpl` и `AmneziaVpnServiceImpl` объявлены
  с `android:supportsAlwaysOn="true"`, это включает системные настройки
  Android "Always-on VPN" + "Блокировать соединения без VPN" (кнопка
  "Открыть настройки VPN" в приложении ведёт прямо туда). Без этого
  тумблера при обрыве туннеля трафик на секунды может пойти в открытую.
- **Авто-переподключение** — `NetworkMonitor` следит за
  `ConnectivityManager` и просит `ProtocolRouter` поднять туннель заново
  при смене сети или восстановлении интернета, независимо от протокола.
- **Свой сервер вместо чужого** — см. `server-deploy/` ниже: не полагаемся
  на чужую инфраструктуру.

## Ключи

`KeyManager` генерирует пару Curve25519 прямо на устройстве и хранит
приватный ключ в `EncryptedSharedPreferences` (AES-256, ключ шифрования —
в Android Keystore). Приватный ключ никогда не покидает устройство и не
хранится в `servers.json` — там нужен только публичный ключ сервера.
Публичный ключ устройства показывается в приложении с кнопками
"Скопировать" и "Новые ключи".

## UI

Главный экран переработан в карточки: статус подключения, выбор сервера
(с пометкой ⚠ у ещё не реализованных протоколов), параметры обфускации
для AmneziaWG, управление ключами устройства, kill switch.

## Свой бесплатный сервер (`server-deploy/`)

Никаких списков "бесплатных публичных VPN" — такие списки либо не
работают, либо это чужой сервер, видящий весь твой трафик. Вместо этого:

- `server-deploy/deploy-wireguard-awg.sh` — скрипт, разворачивающий на
  чистом Ubuntu WireGuard и/или AmneziaWG одной командой и печатающий
  всё, что нужно вставить в `servers.json`.
- `server-deploy/README.md` — таблица реальных бесплатных VPS-тарифов
  (Oracle Cloud Always Free — самый щедрый и бессрочный, Google/AWS/Azure
  free tier, Fly.io) и пошаговая инструкция.

## V2Ray/Trojan: сборка .aar

Код полностью готов (`vpn/xray/XrayManager.kt`, `V2RayVpnService.kt`,
`XrayConfigBuilder.kt`), но библиотека xray-core под Android — это
Go-проект, который не публикуется на Maven Central, поэтому его нужно
собрать один раз у себя:

```bash
cd xray-build
./build-libv2ray.sh        # требует Go 1.21+, ANDROID_HOME, NDK
cp libv2ray.aar ../app/libs/libv2ray.aar
```

Сборка занимает 10-20 минут (компилируется весь xray-core под ARM/x86
Android-таргеты через gomobile). После этого V2Ray и Trojan в приложении
работают по-настоящему: `V2RayVpnService` поднимает системный TUN-интерфейс
и напрямую отдаёт его файловый дескриптор в `CoreController.startLoop()` —
дальше весь разбор IP-пакетов и туннелирование делает сам xray-core.

Формат серверов в `servers.json`:
- **V2Ray** — поле `v2rayConfigJson` содержит готовый JSON-объект outbound
  (protocol/settings/streamSettings) — например, экспортированный из
  панели 3x-ui/x-ui или собранный вручную из vmess://.../vless://... ссылки.
- **Trojan** — поля `trojanPassword` и `trojanSni`, `endpoint` в формате
  `host:port`; `XrayConfigBuilder` сам соберёт нужный outbound с TLS.

Если V2Ray/Trojan пока не нужны — закомментируй строку
`implementation files('libs/libv2ray.aar')` в `app/build.gradle`, всё
остальное (WireGuard, AmneziaWG) соберётся и без неё.

## Перед первой сборкой — обязательно

1. Разверни свой сервер (`server-deploy/`) и замени плейсхолдеры в
   `app/src/main/assets/servers.json` на реальные `serverPublicKey`,
   `endpoint` и (для AmneziaWG) параметры обфускации.
2. Задай реальный `SERVERS_URL` в `ApiClient.kt`, если будет свой backend
   со списком серверов, либо оставь только `assets/servers.json`.
3. `minSdk 24` — требование библиотек WireGuard/AmneziaWG.
4. Открой в Android Studio, дай Gradle синхронизироваться — обе
   WireGuard-библиотеки подтянут нативные `.so` автоматически.

## Дальнейшие шаги (по желанию)

- Довести до реальной работы один из протоколов-заглушек — начать
  разумнее с V2Ray/Trojan (общее ядро xray-core, один `.aar` на оба).
- Перенести `NetworkMonitor` в foreground-сервис, чтобы автопереподключение
  работало и при полностью свёрнутом/убитом приложении.
- Ротация ключей по расписанию с UI-подтверждением "ключ обновлён на сервере".
- Несколько endpoint'ов на один сервер (fallback IP/порт), если основной
  заблокирован — актуально вместе с AmneziaWG.
